# Arabic Hospitality Request Management System

A Flask-based web application for managing hospitality requests with Arabic language support, Gmail integration, and Telegram bot notifications.

## Features

- Arabic RTL form interface with Bootstrap 5
- Gmail API integration for email notifications
- Telegram bot for request approval/rejection
- PDF generation for record keeping
- File upload support
- Phone number validation for Egyptian numbers

## Setup

1. Install dependencies:
```bash
pip install -r requirements.txt
```

2. Set up environment variables:
```bash
export SESSION_SECRET="your-session-secret"
export SENDER_EMAIL="your-gmail@gmail.com"
export RECIPIENT_EMAIL="recipient@gmail.com"
export TELEGRAM_BOT_TOKEN="your-telegram-bot-token"
```

3. Set up Gmail API credentials:
- Place your `credentials.json` file in the project root
- Run the authentication setup once

4. Run the application:
```bash
python main.py
```

## File Structure

- `main.py` - Application entry point
- `app.py` - Main Flask application
- `gmail_auth.py` - Gmail API authentication
- `telegram_bot.py` - Telegram bot handlers
- `utils.py` - Utility functions
- `templates/` - HTML templates
- `static/` - CSS and JavaScript files
- `tokens/` - OAuth token storage
- `pdfs/` - Generated PDF records
- `uploads/` - File uploads storage

## Deployment

The application is configured for deployment on Replit with Gunicorn.